package com.team2.service.impl;

import com.team2.form.AddressForm;
import com.team2.service.*;
import com.team2.vo.HomeVO;
import com.team2.vo.MenuVO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.math.BigDecimal;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"classpath:springmvc.xml","classpath:mybatisConfig.xml","classpath:spring.xml"})
public class ServiceImplTest {
    @Autowired
    private AddressService addressService;

    @Autowired
    private CartService cartService;

    @Autowired
    private HomeService homeService;

    @Autowired
    private LoginService loginService;

    @Autowired
    private MenuService menuService;

    @Autowired
    private OrderService orderService;

    @Autowired
    private UserService userService;

    //LoginService
    @Test
    public void registerByName() {
        loginService.registerByName(
                "test","1234","12345677","General user");
    }

    @Test
    public void loginByName() {
        loginService.loginByName("test", "1234");
    }

    //HomeService
    @Test
    public void findAllRestaurants() {
        HomeVO homeVO = homeService.findAllRestaurants();
        System.out.println(homeVO);
    }

    //MenuService
    @Test
    public void menuShow() {
        MenuVO menuVO = menuService.menuShow(1);
        System.out.println(menuVO);
    }

    //CartService
    @Test
    public void addItemTest() {
        cartService.addItem(1,1,5);
    }

    @Test
    public void updateItemTest() {
        cartService.updateItem(59,1);
    }

    @Test
    public void deleteItemTest() {
        cartService.deleteItem(59);
    }

    @Test
    public void deleteAllInCartTest() {
        cartService.deleteAllInCart(3);
    }

    //AddressService
    @Test
    public void addAddressTest() {
        AddressForm addressForm = new AddressForm();
        addressForm.setUserId(1);
        addressForm.setName("babao00");
        addressForm.setAddress("Manchester");
        addressForm.setPostcode("M156JG");
        addressForm.setTel("7577383747");
        addressService.addAddress(addressForm);
    }

    @Test
    public void deleteAddressTest() {
        addressService.deleteAddress(12);
    }

    @Test
    public void viewAddressTest() {
        System.out.println(addressService.viewAddresses(1));
    }

    //OrderService
    @Test
    public void checkBalanceTest() {
        BigDecimal balance = orderService.checkBalance(1);
        System.out.println(balance);
    }

    @Test
    public void createOrderTest() {
        cartService.addItem(1,2,5);
        cartService.viewCart(1);
        orderService.createOrder(1,4,"balance");
    }

    @Test
    public void viewAllOrdersTest() {
        System.out.println(orderService.viewAllOrders(1));
    }

    //UserService
    @Test
    public void getNameTest() {
        System.out.println(userService.getName(7));
    }

    @Test
    public void rechargeTest() {
        System.out.println(orderService.checkBalance(7));
        userService.recharge(1, BigDecimal.valueOf(200));
    }

    @Test
    public void testIsVip() {
        System.out.println(userService.isVip(1));
        System.out.println(userService.isVip(7));
    }

    @Test
    public void openVipTest() {
        userService.openVip(7, "balance");
        System.out.println(userService.isVip(7));
    }

}
