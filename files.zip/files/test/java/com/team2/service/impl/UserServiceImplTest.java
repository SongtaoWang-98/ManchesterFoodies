package com.team2.service.impl;

import com.team2.service.OrderService;
import com.team2.service.UserService;
import junit.framework.TestCase;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.math.BigDecimal;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"classpath:springmvc.xml","classpath:mybatisConfig.xml","classpath:spring.xml"})
public class UserServiceImplTest extends TestCase {

    @Autowired
    private UserService userService;

    @Autowired
    private OrderService orderService;

    @Test
    public void testIsVip() {
        System.out.println(userService.isVip(1));
        System.out.println(userService.isVip(4));
    }

    @Test
    public void openVipTest() {
        userService.openVip(8, "balance");
        System.out.println(orderService.checkBalance(8));
        System.out.println(userService.isVip(8));
    }

    @Test
    public void rechargeTest() {
        System.out.println(orderService.checkBalance(8));
        userService.recharge(8, BigDecimal.valueOf(200));
        System.out.println(orderService.checkBalance(8));
    }

}